document.addEventListener('DOMContentLoaded', () => {
    
    // --- Config ---
    const config = {
        userName: localStorage.getItem('et_name') || 'USER',
        blur: localStorage.getItem('et_blur') || 24,
        borderRadius: localStorage.getItem('et_radius') || 20,
        dockScale: localStorage.getItem('et_dock_scale') || 1,
        showDock: localStorage.getItem('et_dock') !== 'false',
        dockAutoHide: localStorage.getItem('et_dock_hide') === 'true',
        dockMagnification: localStorage.getItem('et_dock_mag') === 'true',
        dockHoverName: localStorage.getItem('et_dock_names') === 'true',
        dockMagStrength: parseFloat(localStorage.getItem('et_dock_mag_str') || '0.75'),
        theme: localStorage.getItem('et_theme') || 'dark',
        font: localStorage.getItem('et_font') || 'Inter',
        bgImage: localStorage.getItem('et_bg') || null,
        userWallpapers: JSON.parse(localStorage.getItem('et_user_wallpapers') || '[]'),
        use24h: localStorage.getItem('et_24h') === 'true',
        showSeconds: localStorage.getItem('et_seconds') === 'true',
        gridAlign: localStorage.getItem('et_grid_align') || 'center',
        layoutOrder: JSON.parse(localStorage.getItem('et_layout') || '["widget-clock", "widget-stack", "widget-search", "widget-todo", "widget-recents"]'),
        hiddenWidgets: JSON.parse(localStorage.getItem('et_hidden') || '["widget-notes", "widget-bookmarks", "widget-countdown", "widget-music"]'),
        sidebarWidget: localStorage.getItem('et_sidebar_widget') || null,
        stickers: JSON.parse(localStorage.getItem('et_stickers') || '[]'),
        customStickers: JSON.parse(localStorage.getItem('et_custom_stickers') || '[]'),
        searchHalfWidth: localStorage.getItem('et_search_half') === 'true',
        experimental: localStorage.getItem('et_experimental') === 'true',
        coverSize: localStorage.getItem('et_cover_size') || 110,
        ambientMode: localStorage.getItem('et_ambient') === 'true',
        albumGlow: localStorage.getItem('et_album_glow') === 'true',
        emojiIcons: localStorage.getItem('et_emoji_icons') === 'true',
        countdownDate: localStorage.getItem('et_cd_date') || null,
        countdownLabel: localStorage.getItem('et_cd_label') || 'EVENT',
        briefAutoShow: localStorage.getItem('et_brief_auto') !== 'false',
        briefNewsTopic: localStorage.getItem('et_brief_topic') || 'tech',
        briefOrder: JSON.parse(localStorage.getItem('et_brief_order') || '["greeting", "weather", "tasks", "fact", "quote", "news", "music", "surprise"]'),
        currentAudioTabId: null,
        minecraftTheme: localStorage.getItem('et_mc_theme') === 'true',
        // User Card Config
        userCard: JSON.parse(localStorage.getItem('et_user_card') || JSON.stringify({
            id: '#' + Math.floor(1000 + Math.random() * 9000), // Fixed random ID
            color: '#d71921',
            font: 'Space Mono',
            image: null,
            name: 'USER' // Independent display name for card
        }))
    };

    const changelogs = [
        { version: '4.5.1', date: '2023-12-26', changes: ['Live News Headlines', 'Daily Challenges with Tracking', 'Fresh Daily Content'] },
        { version: '4.5.0', date: '2023-12-25', changes: ['Revamped History Tab', 'Updated Search Bar Style', 'Optimized User Card', 'Update Log UI Improvements'] },
        { version: '4.4.0', date: '2023-12-20', changes: ['Added Interactive User ID Card', 'Customizable Card Colors', '3D Holographic Effects'] },
        { version: '4.3.0', date: '2023-12-15', changes: ['Added Dock Magnification', 'Dock Hover Names', 'Enhanced UI Animations'] },
        { version: '4.2.0', date: '2023-12-08', changes: ['Wallpaper Playground Grid Layout', 'Emoji Pattern Generator', 'Performance Improvements'] },
        { version: '4.1.0', date: '2023-12-07', changes: ['Added Morning Brief', 'Tint Control', 'Music Layout Fixes'] },
        { version: '4.0.0', date: '2023-11-06', changes: ['Major Update: Version 4.0', 'High Res Music Art Fixes', 'Celebratory Easter Eggs', 'Confetti!'] },
    ];

    // --- Sound FX ---
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const playSound = (type) => {
        if (audioCtx.state === 'suspended') audioCtx.resume();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        
        const now = audioCtx.currentTime;
        if (type === 'click') {
            osc.frequency.setValueAtTime(600, now);
            osc.frequency.exponentialRampToValueAtTime(300, now + 0.1);
            gain.gain.setValueAtTime(0.1, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
            osc.start(now);
            osc.stop(now + 0.1);
        } else if (type === 'delete') {
            osc.frequency.setValueAtTime(300, now);
            osc.frequency.exponentialRampToValueAtTime(100, now + 0.15);
            gain.gain.setValueAtTime(0.1, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
            osc.start(now);
            osc.stop(now + 0.15);
        }
    };

    // --- DOM Elements ---
    const gridContainer = document.getElementById('gridContainer');
    const drawerContent = document.getElementById('drawerContent');
    const stickerContent = document.getElementById('stickerContent');
    const widgetDrawer = document.getElementById('widgetDrawer');
    const closeDrawerBtn = document.getElementById('closeDrawer');
    const editToggle = document.getElementById('editToggle');
    const sidebarContainer = document.getElementById('sidebarContainer');
    const sidebarPlaceholder = document.getElementById('sidebarPlaceholder');
    const settingsModal = document.getElementById('settingsModal');
    const stickerLayer = document.getElementById('stickerLayer');
    const bgVideo = document.getElementById('bgVideo');
    const briefOverlay = document.getElementById('briefOverlay');
    let isEditMode = false;
    let pinnedItems = JSON.parse(localStorage.getItem('et_pinned') || '[]');

    // --- Daily Data Content ---
    const dailyQuotes = [
        "The only way to do great work is to love what you do.",
        "Focus on being productive instead of busy.",
        "Simplicity is the ultimate sophistication.",
        "Every moment is a fresh beginning.",
        "Change the world by being yourself.",
        "Die with memories, not dreams.",
        "Everything you can imagine is real.",
        "Determine your priorities and focus on them.",
        "Be so good they can't ignore you.",
        "Dream big and dare to fail.",
        "Whatever you do, do it well.",
        "What we think, we become.",
        "Act as if what you do makes a difference.",
        "Success is not final, failure is not fatal.",
        "Believe you can and you're halfway there."
    ];

    const dailyFacts = [
        "Honey never spoils. Archaeologists have found pots of honey in ancient Egyptian tombs that are over 3,000 years old.",
        "Octopuses have three hearts.",
        "Bananas are berries, but strawberries aren't.",
        "A day on Venus is longer than a year on Venus.",
        "There are more stars in the universe than grains of sand on all the Earth's beaches.",
        "The Eiffel Tower can be 15 cm taller during the summer due to thermal expansion.",
        "Water makes up about 71% of the Earth's surface.",
        "A bolt of lightning contains enough energy to toast 100,000 slices of bread.",
        "The first computer was invented in the 1940s.",
        "Human teeth are the only part of the body that cannot heal themselves.",
        "Cows have best friends and get stressed when they are separated.",
        "A cloud weighs around a million tonnes.",
        "You can't hum while holding your nose."
    ];

    const dailyChallenges = [
        "Drink 2 liters of water today.",
        "Read 10 pages of a book.",
        "Take a 15-minute walk without your phone.",
        "Declutter one small area of your desk.",
        "Write down 3 things you are grateful for.",
        "Do 20 pushups (or your variation).",
        "Send a kind message to a friend.",
        "Meditate for 5 minutes.",
        "Learn one new word today.",
        "No social media for the next hour.",
        "Fix your posture every time you remember.",
        "Eat one piece of fruit.",
        "Go to bed 30 minutes earlier."
    ];

    // Helper: Seeded Random Selection based on Date
    const getDailyItem = (array) => {
        const todayStr = new Date().toDateString(); // e.g. "Fri Dec 08 2023"
        let hash = 0;
        for (let i = 0; i < todayStr.length; i++) {
            hash = (hash << 5) - hash + todayStr.charCodeAt(i);
            hash |= 0; // Convert to 32bit integer
        }
        const index = Math.abs(hash) % array.length;
        return array[index];
    };

    // --- Morning Brief Logic ---
    const checkMorningBrief = () => {
        const today = new Date().toDateString();
        const lastShown = localStorage.getItem('et_brief_last_shown');
        
        if (config.briefAutoShow && lastShown !== today) {
            openBrief();
        }
    };

    const openBrief = () => {
        renderBriefContent();
        briefOverlay.classList.add('active');
        playSound('click');
        localStorage.setItem('et_brief_last_shown', new Date().toDateString());
    };

    const closeBrief = () => {
        briefOverlay.classList.remove('active');
    };

    document.getElementById('morningBriefBtn').onclick = openBrief;
    document.getElementById('closeBrief').onclick = closeBrief;
    briefOverlay.onclick = (e) => { if (e.target === briefOverlay) closeBrief(); };

    const getMusicRec = () => {
        const h = new Date().getHours();
        if (h < 12) return { genre: 'Acoustic / Lo-Fi', icon: '☕', link: 'https://open.spotify.com/genre/0JQ5DAqbMKFzHmL4tf05da' }; 
        if (h < 18) return { genre: 'Pop / Upbeat', icon: '⚡', link: 'https://open.spotify.com/genre/0JQ5DAqbMKFEC4WFtoNRpw' }; 
        return { genre: 'Jazz / Ambient', icon: '🌙', link: 'https://open.spotify.com/genre/0JQ5DAqbMKFAJ5xb0fwo9m' }; 
    };

    const renderBriefContent = async () => {
        const container = document.getElementById('briefContent');
        container.innerHTML = '';
        
        const now = new Date();
        const dateKey = now.toDateString();
        const todos = JSON.parse(localStorage.getItem('todos') || '[]');
        const rec = getMusicRec();

        // Get fresh daily content
        const dailyQuote = getDailyItem(dailyQuotes);
        const dailyFact = getDailyItem(dailyFacts);
        const dailyChallengeText = getDailyItem(dailyChallenges);

        // Challenge State
        const challengeKey = 'et_challenge_' + dateKey;
        
        // Helper to create sections
        const createSection = (type) => {
            const div = document.createElement('div');
            
            if (type === 'greeting') {
                div.className = 'bento-card greeting span-4';
                div.innerHTML = `<div class="brief-title">GOOD ${now.getHours() < 12 ? 'MORNING' : (now.getHours() < 17 ? 'AFTERNOON' : 'EVENING')},<br>${config.userName}</div>
                <div class="brief-subtitle" style="margin-top: auto;"><span>${now.toLocaleDateString('en-US', {weekday:'long'}).toUpperCase()}</span><span>•</span><span>${now.getDate()} ${now.toLocaleDateString('en-US', {month:'long'}).toUpperCase()}</span></div>`;
            } 
            else if (type === 'weather') {
                div.className = 'bento-card weather span-2';
                div.innerHTML = `<div class="bento-label"><span>WEATHER</span><span>LIVE</span></div>
                <div class="brief-big-text" id="briefWeather">--°</div>`;
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(async (pos) => {
                        try {
                            const res = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${pos.coords.latitude}&longitude=${pos.coords.longitude}&current=temperature_2m`);
                            const data = await res.json();
                            const el = document.getElementById('briefWeather');
                            if(el) el.innerText = Math.round(data.current.temperature_2m) + '°';
                        } catch(e) {}
                    });
                }
            }
            else if (type === 'tasks') {
                div.className = 'bento-card span-2';
                const activeTasks = todos.filter(t => !t.done).slice(0, 3);
                let taskHTML = activeTasks.length ? activeTasks.map(t => `<div class="bento-list-item"><div class="bento-check"></div><span>${t.text}</span></div>`).join('') : '<span style="color:#666; font-size:0.8rem; margin-top: auto;">No pending tasks.<br>You are free!</span>';
                div.innerHTML = `<div class="bento-label"><span>PRIORITIES</span><span style="color:var(--accent);">${activeTasks.length}</span></div><div class="bento-list">${taskHTML}</div>`;
            }
            else if (type === 'fact') {
                div.className = 'bento-card span-1';
                div.innerHTML = `<div class="bento-label"><span>DID YOU KNOW?</span></div>
                <div style="font-size:0.8rem; line-height:1.4; color:#ccc; margin-top:auto;">${dailyFact}</div>`;
            }
            else if (type === 'quote') {
                div.className = 'bento-card span-2';
                div.innerHTML = `<div class="bento-label"><span>QUOTE OF THE DAY</span></div>
                <div style="font-size:1.1rem; font-style:italic; font-family:var(--font-ui); color:#fff; margin-top:auto;">"${dailyQuote}"</div>`;
            }
            else if (type === 'news') {
                div.className = 'bento-card news span-4';
                div.innerHTML = `<div class="bento-label"><span>HEADLINES</span><span>${config.briefNewsTopic.toUpperCase()}</span></div>
                <div id="briefNewsContent" style="display:flex; flex-direction:column; gap:10px; flex-grow:1; justify-content:center;">
                    <div style="color:#666; font-size:0.9rem;">Fetching ${config.briefNewsTopic} headlines...</div>
                </div>
                <button id="briefNewsBtn" style="margin-top:10px; background:rgba(255,255,255,0.1); border:none; padding:8px 12px; border-radius:6px; color:#fff; cursor:pointer; font-size:0.75rem; font-weight:bold; align-self:flex-start; transition:background 0.2s;">READ MORE →</button>`;
                
                // Fetch Logic using RSS2JSON for Google News to avoid CORS and get "actual" headlines
                const fetchNews = async () => {
                    try {
                        const rssUrl = `https://news.google.com/rss/search?q=${encodeURIComponent(config.briefNewsTopic)}&hl=en-US&gl=US&ceid=US:en`;
                        const res = await fetch(`https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(rssUrl)}`);
                        const data = await res.json();
                        
                        const newsCont = div.querySelector('#briefNewsContent');
                        if (data.items && data.items.length > 0) {
                            newsCont.innerHTML = '';
                            newsCont.style.justifyContent = 'flex-start';
                            
                            data.items.slice(0, 3).forEach(item => {
                                const row = document.createElement('div');
                                row.style.cssText = "font-size:0.9rem; border-bottom:1px solid rgba(255,255,255,0.1); padding:8px 0; cursor:pointer; transition:color 0.2s; color:#ccc;";
                                row.innerText = item.title;
                                row.onmouseover = () => row.style.color = '#fff';
                                row.onmouseout = () => row.style.color = '#ccc';
                                row.onclick = () => window.open(item.link, '_blank');
                                newsCont.appendChild(row);
                            });
                            
                            const btn = div.querySelector('#briefNewsBtn');
                            btn.onclick = () => window.open(`https://news.google.com/search?q=${config.briefNewsTopic}`, '_blank');
                            btn.onmouseover = () => btn.style.background = 'rgba(255,255,255,0.2)';
                            btn.onmouseout = () => btn.style.background = 'rgba(255,255,255,0.1)';
                        } else {
                            throw new Error("No items");
                        }
                    } catch (e) {
                         const newsCont = div.querySelector('#briefNewsContent');
                         if(newsCont) newsCont.innerHTML = `<div style="color:#d71921;">Unable to load live feed.</div>`;
                         const btn = div.querySelector('#briefNewsBtn');
                         if(btn) btn.onclick = () => window.open(`https://news.google.com/search?q=${config.briefNewsTopic}`, '_blank');
                    }
                };
                fetchNews();
            }
            else if (type === 'music') {
                div.className = 'bento-card music span-2';
                div.onclick = () => window.open(rec.link, '_blank');
                div.innerHTML = `<div style="font-size:2rem; margin-bottom:10px;">${rec.icon}</div>
                <div style="display:flex; flex-direction:column;"><span style="font-size:0.7rem; font-weight:bold; letter-spacing:1px; opacity:0.7;">VIBE CHECK</span><span style="font-size:1.5rem; font-weight:700;">${rec.genre}</span></div>`;
            }
            else if (type === 'surprise') {
                // Modified to be Daily Challenge
                div.className = 'bento-card span-1';
                div.style.border = '1px dashed var(--accent)';
                
                const renderChallenge = () => {
                    const done = localStorage.getItem(challengeKey) === 'true';
                    div.innerHTML = `<div class="bento-label" style="color:var(--accent);"><span>DAILY CHALLENGE</span></div>
                    <div style="font-size:0.9rem; font-weight:bold; margin-bottom:10px; line-height:1.4;">${dailyChallengeText}</div>
                    <div id="challengeCheck" style="display:flex; align-items:center; gap:8px; cursor:pointer; margin-top:auto; padding-top:10px;">
                        <div style="width:20px; height:20px; border:2px solid var(--accent); border-radius:4px; display:flex; align-items:center; justify-content:center; background:${done ? 'var(--accent)' : 'transparent'}">
                            ${done ? '<span style="color:black; font-weight:bold; font-size:14px;">✓</span>' : ''}
                        </div>
                        <span style="font-size:0.75rem; font-weight:bold; color:${done ? '#fff' : '#888'}">${done ? 'COMPLETED' : 'MARK DONE'}</span>
                    </div>`;
                    
                    setTimeout(() => {
                        const checkBtn = div.querySelector('#challengeCheck');
                        if(checkBtn) checkBtn.onclick = () => {
                             const newState = !done;
                             localStorage.setItem(challengeKey, newState);
                             playSound('click');
                             if(newState && typeof startConfetti === 'function') startConfetti();
                             renderChallenge();
                        };
                    }, 0);
                };
                renderChallenge();
            }
            
            container.appendChild(div);
        };

        config.briefOrder.forEach(section => createSection(section));
    };

    // Initialize Brief
    setTimeout(checkMorningBrief, 1000);

    
    // --- STICKERS ---
    const renderStickers = () => {
        stickerLayer.innerHTML = '';
        config.stickers.forEach(s => {
            const div = document.createElement('div');
            div.className = 'placed-sticker';
            div.id = s.id;
            div.style.left = s.x + '%';
            div.style.top = s.y + '%';
            // Rotation Transform
            div.style.transform = `translate(-50%, -50%) rotate(${s.rotation || 0}deg)`;
            
            if (s.type === 'custom') {
                div.innerHTML = `<img src="${s.src}">`;
            } else {
            const preset = document.querySelector(`.sticker-item.preset[data-type="${s.type}"]`);
                if(preset) div.innerHTML = preset.innerHTML;
            }

            // Edit Mode Controls
            if (isEditMode) {
                // Delete Button (Top-Right)
                const delBtn = document.createElement('div');
                delBtn.className = 'sticker-control-btn sticker-delete';
                delBtn.innerHTML = '×';
                delBtn.onclick = (e) => {
                    e.stopPropagation();
                    playSound('delete');
                    config.stickers = config.stickers.filter(i => i.id !== s.id);
                    localStorage.setItem('et_stickers', JSON.stringify(config.stickers));
                    renderStickers();
                };
                div.appendChild(delBtn);

                // Rotate Button (Bottom-Right)
                const rotBtn = document.createElement('div');
                rotBtn.className = 'sticker-control-btn sticker-rotate';
                rotBtn.innerHTML = '⟳';
                rotBtn.onmousedown = (e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    div.style.transition = 'none'; // Disable transition for instant response
                    
                    // Calculate center based on percentages
                    const cx = (s.x / 100) * window.innerWidth;
                    const cy = (s.y / 100) * window.innerHeight;
                    
                    const onRotate = (mv) => {
                        // Calculate angle in degrees
                        const angle = Math.atan2(mv.clientY - cy, mv.clientX - cx);
                        const deg = angle * (180 / Math.PI) - 45; // -45 to align handle correctly
                        
                        s.rotation = deg;
                        div.style.transform = `translate(-50%, -50%) rotate(${deg}deg)`;
                    };
                    
                    const onEndRotate = () => {
                        document.removeEventListener('mousemove', onRotate);
                        document.removeEventListener('mouseup', onEndRotate);
                        div.style.transition = ''; // Restore transition
                        localStorage.setItem('et_stickers', JSON.stringify(config.stickers));
                    };
                    document.addEventListener('mousemove', onRotate);
                    document.addEventListener('mouseup', onEndRotate);
                };
                div.appendChild(rotBtn);
            }

            // Drag Logic for placed stickers (Movement)
            div.addEventListener('mousedown', (e) => {
                if(!isEditMode) return;
                // Ignore if clicked on controls
                if(e.target.classList.contains('sticker-control-btn')) return;
                
                e.stopPropagation();
                div.style.transition = 'none'; // Disable transition for instant response
                
                let startX = e.clientX;
                let startY = e.clientY;
                // Current rotation must be preserved during drag visual
                const currentRot = s.rotation || 0;
                
                const onMove = (mv) => {
                    const dx = mv.clientX - startX;
                    const dy = mv.clientY - startY;
                    div.style.transform = `translate(-50%, -50%) translate(${dx}px, ${dy}px) rotate(${currentRot}deg)`;
                };
                
                const onUp = (up) => {
                    document.removeEventListener('mousemove', onMove);
                    document.removeEventListener('mouseup', onUp);
                    div.style.transition = ''; // Restore transition
                    
                    const winW = window.innerWidth;
                    const winH = window.innerHeight;
                    
                    // Calculate delta in percentage
                    const deltaXPercent = ((up.clientX - startX) / winW) * 100;
                    const deltaYPercent = ((up.clientY - startY) / winH) * 100;
                    
                    s.x += deltaXPercent;
                    s.y += deltaYPercent;
                    
                    localStorage.setItem('et_stickers', JSON.stringify(config.stickers));
                    renderStickers();
                };
                document.addEventListener('mousemove', onMove);
                document.addEventListener('mouseup', onUp);
            });
            stickerLayer.appendChild(div);
        });
    };
    
    const renderCustomStickers = () => {
        const cont = document.getElementById('customStickerContainer');
        cont.innerHTML = '';
        config.customStickers.forEach((src, idx) => {
            const div = document.createElement('div');
            div.className = 'sticker-item';
            div.draggable = true;
            div.dataset.type = 'custom';
            div.dataset.idx = idx;
            div.innerHTML = `<img src="${src}">`;
            div.addEventListener('dragstart', handleStickerDragStart);
            // Delete custom
            div.addEventListener('contextmenu', (e) => {
                e.preventDefault();
                if(confirm('Remove custom sticker from library?')) {
                    config.customStickers.splice(idx, 1);
                    localStorage.setItem('et_custom_stickers', JSON.stringify(config.customStickers));
                    renderCustomStickers();
                }
            });
            cont.appendChild(div);
        });
    };

    // Sticker Upload
    document.getElementById('stickerUpload').addEventListener('change', (e) => {
        if(config.customStickers.length >= 5) { alert('Max 5 custom stickers.'); return; }
        const file = e.target.files[0];
        if(!file) return;
        const reader = new FileReader();
        reader.onload = (evt) => {
            config.customStickers.push(evt.target.result);
            localStorage.setItem('et_custom_stickers', JSON.stringify(config.customStickers));
            renderCustomStickers();
        };
        reader.readAsDataURL(file);
    });

    const handleStickerDragStart = (e) => {
        e.dataTransfer.setData('type', 'sticker');
        e.dataTransfer.setData('stickerType', e.currentTarget.dataset.type);
        if(e.currentTarget.dataset.type === 'custom') {
             e.dataTransfer.setData('stickerSrc', config.customStickers[e.currentTarget.dataset.idx]);
        }
    };
    
    document.querySelectorAll('.sticker-item.preset').forEach(el => {
        el.addEventListener('dragstart', handleStickerDragStart);
    });

    renderStickers();
    renderCustomStickers();

    // --- Clock Logic ---
    const updateTime = () => {
        const now = new Date();
        const opts = { hour12: !config.use24h, hour: '2-digit', minute: '2-digit' };
        if(config.showSeconds) opts.second = '2-digit';
        document.getElementById('clockTime').textContent = now.toLocaleTimeString('en-US', opts);
        const hrs = now.getHours();
        document.getElementById('greetingText').textContent = hrs < 12 ? 'GOOD MORNING' : (hrs < 17 ? 'GOOD AFTERNOON' : 'GOOD EVENING');
        document.getElementById('calDay').textContent = now.toLocaleDateString('en-US', {weekday:'short'}).toUpperCase();
        document.getElementById('calDate').textContent = now.getDate();
        document.getElementById('clockDateFull').textContent = now.toLocaleDateString('en-US', {weekday:'long', month:'short', day:'numeric'}).toUpperCase();
        
        // Countdown Logic
        const label = config.countdownLabel || 'EVENT';
        document.getElementById('countdownLabel').textContent = label;
        
        if(config.countdownDate) {
            // Construct date in local time to avoid timezone issues (YYYY-MM-DD input is local)
            const parts = config.countdownDate.split('-');
            const target = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
            // Clear time part of target
            target.setHours(0,0,0,0);
            
            const today = new Date();
            today.setHours(0,0,0,0);
            
            const diff = target - today;
            const daysLeft = Math.ceil(diff / (1000 * 60 * 60 * 24));
            
            if (daysLeft > 0) document.getElementById('countdownTime').textContent = daysLeft + ' DAYS';
            else if (daysLeft === 0) document.getElementById('countdownTime').textContent = 'TODAY';
            else document.getElementById('countdownTime').textContent = 'PASSED';

            // Progress Bar
            const startTime = localStorage.getItem('et_cd_start');
            if (startTime) {
                const start = new Date(parseInt(startTime));
                const total = target - start;
                const elapsed = today - start;
                const pct = Math.min(100, Math.max(0, (elapsed / total) * 100));
                const fill = document.getElementById('countdownFill');
                if(fill) fill.style.width = pct + '%';
            }
        }
    };
    setInterval(updateTime, 1000); updateTime();

    // Calendar Month View Logic (Dynamic)
    document.getElementById('calToggleView').addEventListener('click', () => {
        const simple = document.getElementById('calSimpleView');
        const month = document.getElementById('calMonthView');
        simple.classList.toggle('hidden');
        month.classList.toggle('hidden');
        
        if (!month.classList.contains('hidden')) {
            const now = new Date();
            const grid = document.getElementById('calGrid');
            grid.innerHTML = '';
            
            const monthName = now.toLocaleDateString('en-US', { month: 'long' }).toUpperCase();
            document.getElementById('calMonthName').textContent = monthName;
            
            const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).getDay(); // 0-6
            const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
            
            for (let i = 0; i < firstDay; i++) {
                const d = document.createElement('div');
                d.className = 'grid-day';
                grid.appendChild(d);
            }
            
            for (let i = 1; i <= daysInMonth; i++) {
                const d = document.createElement('div');
                d.className = 'grid-day' + (i === now.getDate() ? ' today' : '');
                d.textContent = i;
                grid.appendChild(d);
            }
        }
    });

    // Countdown Save Handler
    document.getElementById('saveCountdownBtn').addEventListener('click', () => {
        const label = document.getElementById('countdownLabelInput').value;
        const date = document.getElementById('countdownDateInput').value;
        
        if (date) {
            localStorage.setItem('et_cd_label', label);
            localStorage.setItem('et_cd_date', date);
            config.countdownLabel = label;
            config.countdownDate = date;
            
            // Set start date if new
            if (!localStorage.getItem('et_cd_start')) {
                localStorage.setItem('et_cd_start', Date.now().toString());
            }
            
            updateTime();
            alert('Countdown Updated');
        } else {
            alert('Please select a valid date');
        }
    });

    // --- Weather ---
    const updateWeather = async () => {
        if (!navigator.geolocation) {
             document.getElementById('weatherDesc').textContent = 'GPS NA';
             return;
        }
        navigator.geolocation.getCurrentPosition(async (pos) => {
            try {
                const res = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${pos.coords.latitude}&longitude=${pos.coords.longitude}&current=temperature_2m,weather_code`);
                const data = await res.json();
                document.getElementById('weatherTemp').textContent = Math.round(data.current.temperature_2m) + '°';
                document.getElementById('weatherDesc').textContent = 'LAT: ' + pos.coords.latitude.toFixed(2);
            } catch(e) {
                document.getElementById('weatherDesc').textContent = 'ERR';
            }
        }, () => {
            document.getElementById('weatherDesc').textContent = 'GPS OFF';
        });
    };
    updateWeather();

    // Stack Logic
    let stackIdx = 0; const stacks = ['view-weather', 'view-music', 'view-calendar'];
    const updateStack = () => {
        stacks.forEach((id, i) => document.getElementById(id).classList.toggle('active', i === stackIdx));
        document.getElementById('stackDots').innerHTML = stacks.map((_, i) => `<div class="stack-dot ${i === stackIdx ? 'active' : ''}"></div>`).join('');
    };
    document.getElementById('nextStack').onclick = () => { stackIdx = (stackIdx + 1) % 3; updateStack(); };
    document.getElementById('prevStack').onclick = () => { stackIdx = (stackIdx - 1 + 3) % 3; updateStack(); };
    updateStack();

    // Recents (History Fallback)
    const renderRecents = () => {
        const list = document.getElementById('recentsList');
        list.innerHTML = '';
        if (chrome.history) {
             chrome.history.search({text: '', maxResults: 7}, (results) => {
                 results.forEach(page => {
                     const a = document.createElement('a'); a.className = 'list-item'; a.href = page.url;
                     a.innerHTML = `<img src="https://www.google.com/s2/favicons?sz=64&domain_url=${page.url}"><span>${page.title || page.url}</span>`;
                     list.appendChild(a);
                 });
             });
        } else if (chrome.topSites) {
            chrome.topSites.get(sites => {
                sites.slice(0, 7).forEach(site => {
                    const a = document.createElement('a'); a.className = 'list-item'; a.href = site.url;
                    a.innerHTML = `<img src="https://www.google.com/s2/favicons?sz=64&domain_url=${site.url}"><span>${site.title}</span>`;
                    list.appendChild(a);
                });
            });
        }
    };
    renderRecents();
    
    // --- Bookmarks Logic ---
    const renderBookmarks = () => {
         if(!chrome.bookmarks) return;
         
         // 1. For Widget
         const widgetList = document.getElementById('bookmarksList');
         if(widgetList) {
             widgetList.innerHTML = '';
             chrome.bookmarks.getRecent(7, (items) => {
                 items.forEach(item => {
                     const a = document.createElement('a'); a.className = 'list-item'; a.href = item.url;
                     a.innerHTML = `<img src="https://www.google.com/s2/favicons?sz=64&domain_url=${item.url}"><span>${item.title}</span>`;
                     widgetList.appendChild(a);
                 });
             });
         }
         
         // 2. For Library Modal
         const libContent = document.getElementById('libraryContent');
         if(libContent) {
              libContent.innerHTML = '';
              chrome.bookmarks.getRecent(20, (items) => {
                 items.forEach(item => {
                     const div = document.createElement('div'); div.className = 'library-item';
                     div.onclick = () => window.location.href = item.url;
                     div.innerHTML = `<img src="https://www.google.com/s2/favicons?sz=64&domain_url=${item.url}"><span>${item.title}</span>`;
                     libContent.appendChild(div);
                 });
              });
         }
    };
    renderBookmarks();

    
    // --- Media Controller System (Robust Version) ---

    const mediaState = {
        title: 'No Audio',
        artist: 'Start media',
        art: '',
        curr: 0,
        dur: 0,
        playing: false,
        domain: '',
        shuffle: false,
        repeat: false
    };

    const resetMediaUI = () => {
        const update = (suffix) => {
            const elTitle = document.getElementById('musicTitle' + suffix);
            const elArtist = document.getElementById('musicArtist' + suffix);
            const elArt = document.getElementById('musicArt' + suffix);
            const elIcon = document.getElementById('musicIcon' + suffix);
            const elProg = document.getElementById('musicProgressFill' + suffix);
            const elPlay = document.getElementById('iconPlay' + suffix);
            const elPause = document.getElementById('iconPause' + suffix);
            const elTimeC = document.getElementById('musicTimeCurrent' + suffix);
            const elTimeT = document.getElementById('musicTimeTotal' + suffix);

            if (elTitle) elTitle.textContent = 'No Audio';
            if (elArtist) elArtist.textContent = 'Start media';
            if (elArt) elArt.src = '';
            if (elIcon) {
                elIcon.classList.remove('has-art', 'active-glow');
                elIcon.style.removeProperty('--current-art');
            }
            if (elProg) elProg.style.width = '0%';
            if (elPlay) elPlay.classList.remove('hidden');
            if (elPause) elPause.classList.add('hidden');
            if (elTimeC) elTimeC.textContent = '0:00';
            if (elTimeT) elTimeT.textContent = '0:00';
        };
        update('');
        update('_sa');
        if (config.ambientMode) document.documentElement.style.removeProperty('--art-url');
        config.currentAudioTabId = null;
    };

    // INJECTED SCRIPT
    const extractionScript = () => {
        const result = {
            title: '',
            artist: '',
            art: '',
            curr: 0,
            dur: 0,
            playing: false,
            domain: window.location.hostname,
            hasMedia: false,
            timestamp: Date.now()
        };

        try {
            // Strategy 1: MediaSession API (Gold Standard)
            if (navigator.mediaSession && navigator.mediaSession.metadata) {
                const md = navigator.mediaSession.metadata;
                result.title = md.title;
                result.artist = md.artist;
                result.hasMedia = true;
                if (md.artwork && md.artwork.length > 0) {
                    // Pick largest
                    const biggest = [...md.artwork].sort((a,b) => {
                        const wA = parseInt(a.sizes?.split('x')[0] || '0');
                        const wB = parseInt(b.sizes?.split('x')[0] || '0');
                        return wB - wA;
                    });
                    result.art = biggest[0].src;
                }
            }

            // Strategy 2: Document Title Parsing (Robust Fallback)
            if (!result.title || result.title.trim() === '') {
                const docTitle = document.title;
                if (result.domain.includes('spotify')) {
                    // "Song • Artist"
                    const parts = docTitle.split(' • ');
                    if (parts.length >= 2) {
                        result.title = parts[0];
                        result.artist = parts[1];
                        result.hasMedia = true;
                    }
                } else if (result.domain.includes('youtube')) {
                    // "(1) Title - YouTube"
                    const clean = docTitle.replace(/^(d+)s+/, '').replace(/ - YouTube$/, '');
                    result.title = clean;
                    result.hasMedia = true;
                } else if (result.domain.includes('soundcloud')) {
                    // "Artist - Song" or "Song by Artist"
                    const parts = docTitle.split(' by ');
                    if (parts.length >= 2) {
                        result.title = parts[0];
                        result.artist = parts[1];
                        result.hasMedia = true;
                    } else {
                         result.title = docTitle;
                    }
                }
            }

            // Strategy 3: DOM Scraper for Time & State
            // Generic Video/Audio
            const media = document.querySelector('video, audio');
            if (media) {
                result.curr = media.currentTime;
                result.dur = media.duration;
                result.playing = !media.paused;
                // If we found a playing video but no metadata, treat as media
                if (!media.paused && !result.hasMedia) {
                     result.hasMedia = true;
                     if(!result.title) result.title = document.title;
                }
            }

            // Spotify Specifics
            if (result.domain.includes('spotify')) {
                const playBtn = document.querySelector('[data-testid="control-button-playpause"]');
                if (playBtn) {
                    const label = playBtn.getAttribute('aria-label') || '';
                    result.playing = label.toLowerCase().includes('pause');
                    result.hasMedia = true;
                }
                
                const posEl = document.querySelector('[data-testid="playback-position"]');
                const durEl = document.querySelector('[data-testid="playback-duration"]');
                const parseT = (t) => {
                    if (!t) return 0;
                    const p = t.split(':').map(Number);
                    if (p.length === 2) return p[0]*60 + p[1];
                    if (p.length === 3) return p[0]*3600 + p[1]*60 + p[2];
                    return 0;
                };
                if(posEl) result.curr = parseT(posEl.textContent);
                if(durEl) result.dur = parseT(durEl.textContent);

                // Fallback Art
                if(!result.art) {
                    const cover = document.querySelector('img[data-testid="cover-art-image"]');
                    if(cover) result.art = cover.src;
                }
            }

            return result;
        } catch (e) {
            return null;
        }
    };

    const updateUI = (data) => {
        const updateInstance = (suffix) => {
            const elTitle = document.getElementById('musicTitle' + suffix);
            const elArtist = document.getElementById('musicArtist' + suffix);
            const elArt = document.getElementById('musicArt' + suffix);
            const elIcon = document.getElementById('musicIcon' + suffix);
            const elProg = document.getElementById('musicProgressFill' + suffix);
            const elPlay = document.getElementById('iconPlay' + suffix);
            const elPause = document.getElementById('iconPause' + suffix);
            const elTimeC = document.getElementById('musicTimeCurrent' + suffix);
            const elTimeT = document.getElementById('musicTimeTotal' + suffix);

            if (elTitle) elTitle.textContent = data.title || 'Unknown Title';
            if (elArtist) elArtist.textContent = data.artist || '';

            // Art
            if (data.art && elArt.src !== data.art) {
                elArt.src = data.art;
                if (elIcon) {
                    elIcon.classList.add('has-art');
                    elIcon.style.setProperty('--current-art', `url("${data.art}")`);
                    if (config.albumGlow) elIcon.classList.add('active-glow');
                }
                if (config.ambientMode) document.documentElement.style.setProperty('--art-url', `url("${data.art}")`);
            } else if (!data.art && data.hasMedia) {
                // Keep existing art if fleeting glitch, else clear
            }

            // Play/Pause
            if (data.playing) {
                elPlay?.classList.add('hidden');
                elPause?.classList.remove('hidden');
            } else {
                elPlay?.classList.remove('hidden');
                elPause?.classList.add('hidden');
            }

            // Time
            const fmt = (s) => {
                if (isNaN(s) || !isFinite(s)) return '0:00';
                const m = Math.floor(s / 60);
                const sec = Math.floor(s % 60);
                return `${m}:${sec < 10 ? '0' : ''}${sec}`;
            };
            if (elTimeC) elTimeC.textContent = fmt(data.curr);
            if (elTimeT) elTimeT.textContent = fmt(data.dur);

            // Progress
            if (data.dur > 0 && elProg) {
                const pct = Math.min(100, (data.curr / data.dur) * 100);
                elProg.style.width = pct + '%';
            }
        };

        updateInstance('');
        updateInstance('_sa');
        
        const card = document.getElementById('widget-music');
        if (card) {
            if (data.domain.includes('spotify')) card.classList.add('spotify-mode');
            else card.classList.remove('spotify-mode');
        }
    };

    const loop = () => {
        if (!chrome.tabs || !chrome.scripting) return;

        // Priority 1: Audible Tabs
        chrome.tabs.query({ audible: true }, (tabs) => {
            const valid = tabs.filter(t => t.url && !t.url.startsWith('chrome') && !t.url.startsWith('edge'));
            if (valid.length > 0) {
                queryTab(valid[0]);
            } else {
                // Priority 2: Known Music Domains (even if not audible/paused)
                chrome.tabs.query({
                    url: [
                        "*://*.spotify.com/*",
                        "*://*.youtube.com/*",
                        "*://*.soundcloud.com/*",
                        "*://music.apple.com/*",
                        "*://*.deezer.com/*",
                        "*://*.tidal.com/*"
                    ]
                }, (musicTabs) => {
                    if (musicTabs.length > 0) {
                        // Sort by last accessed to get the most recent one
                        musicTabs.sort((a, b) => b.lastAccessed - a.lastAccessed);
                        queryTab(musicTabs[0]);
                    } else {
                        resetMediaUI();
                    }
                });
            }
        });
    };

    const queryTab = (tab) => {
        if (!tab || !tab.id) return;
        config.currentAudioTabId = tab.id;

        chrome.scripting.executeScript({
            target: { tabId: tab.id, allFrames: true }, // Check all frames (iframes)
            world: 'MAIN', // Required for MediaSession
            func: extractionScript
        }, (results) => {
            if (chrome.runtime.lastError) return;

            // Find the best result among frames
            // Usually the main frame (frameId 0) has the MediaSession, but iframe might have the <video>
            if (results && results.length > 0) {
                // Prioritize results that haveMedia = true
                const best = results.find(r => r.result && r.result.hasMedia);
                if (best) {
                    updateUI(best.result);
                } else if (results[0].result) {
                     // Fallback to main frame result even if empty, to clear UI if needed? 
                     // No, better to hold state if nothing found to avoid flickering
                }
            }
        });
    };

    setInterval(loop, 1000);
    setTimeout(loop, 100);

    // --- Controls ---
    const sendCommand = (action) => {
        if (!config.currentAudioTabId) return;
        chrome.scripting.executeScript({
            target: { tabId: config.currentAudioTabId },
            world: 'MAIN',
            func: (act) => {
                const isSpotify = window.location.hostname.includes('spotify');
                if (isSpotify) {
                    const map = {
                        'play': '[data-testid="control-button-playpause"]',
                        'next': '[data-testid="control-button-skip-forward"]',
                        'prev': '[data-testid="control-button-skip-back"]',
                        'shuffle': '[data-testid="control-button-shuffle"]',
                        'repeat': '[data-testid="control-button-repeat"]'
                    };
                    const btn = document.querySelector(map[act]);
                    if (btn) btn.click();
                } else {
                    const v = document.querySelector('video, audio');
                    if (v) {
                        if (act === 'play') v.paused ? v.play() : v.pause();
                        if (act === 'next') v.currentTime += 10;
                        if (act === 'prev') v.currentTime -= 10;
                    }
                }
            },
            args: [action]
        });
        setTimeout(loop, 200);
    };

    const bind = (id, act) => {
        const el = document.getElementById(id);
        if (el) el.onclick = (e) => { e.stopPropagation(); sendCommand(act); };
    };
    bind('btnPlayPause', 'play');
    bind('btnNext', 'next');
    bind('btnPrev', 'prev');
    bind('btnPlayPause_sa', 'play');
    bind('btnNext_sa', 'next');
    bind('btnPrev_sa', 'prev');
    bind('btnShuffle_sa', 'shuffle');
    bind('btnRepeat_sa', 'repeat');

    
    // --- Grid Initialization ---
    const updateHeaderIcons = () => {
        const briefBtn = document.getElementById('morningBriefBtn');
        const editBtn = document.getElementById('editToggle');
        
        if (config.emojiIcons) {
             briefBtn.innerHTML = '<span style="font-size: 20px;">☀️</span>';
             editBtn.innerHTML = '<span style="font-size: 20px;">🖋️</span>';
        } else {
             briefBtn.innerHTML = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>';
             editBtn.innerHTML = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>';
        }
    };

    const initGridWidgets = () => {
        config.layoutOrder.forEach(id => {
            const el = document.getElementById(id);
            if (el) { gridContainer.appendChild(el); el.classList.remove('hidden'); }
        });
        config.hiddenWidgets.forEach(id => {
            const el = document.getElementById(id);
            if (el) { drawerContent.appendChild(el); el.classList.remove('hidden'); }
        });
        
        if (config.sidebarWidget) {
            const el = document.getElementById(config.sidebarWidget);
            if (el) {
                sidebarContainer.insertBefore(el, sidebarPlaceholder);
                el.classList.remove('hidden');
                el.classList.add('sidebar-mode');
                sidebarPlaceholder.classList.add('hidden');
            }
        }

        if (config.searchHalfWidth) {
            const ws = document.getElementById('widget-search');
            if(ws) ws.classList.add('half-width');
        }

        updateHeaderIcons();
    };
    initGridWidgets();

    const saveLayout = () => {
        const order = Array.from(gridContainer.children).filter(c => c.classList.contains('widget')).map(c => c.id);
        const hidden = Array.from(drawerContent.children).filter(c => c.classList.contains('widget')).map(c => c.id);
        
        const sidebarW = Array.from(sidebarContainer.children).find(c => c.classList.contains('widget'));
        if (sidebarW) {
            localStorage.setItem('et_sidebar_widget', sidebarW.id);
            config.sidebarWidget = sidebarW.id;
            sidebarPlaceholder.classList.add('hidden');
        } else {
            localStorage.removeItem('et_sidebar_widget');
            config.sidebarWidget = null;
            sidebarPlaceholder.classList.remove('hidden');
        }

        localStorage.setItem('et_layout', JSON.stringify(order));
        localStorage.setItem('et_hidden', JSON.stringify(hidden));
        config.hiddenWidgets = hidden;
    };

    // --- Drag & Drop ---
    const widgets = document.querySelectorAll('.widget');
    const cleanWidgetOnDrop = (widget) => {
        widget.classList.remove('dragging', 'sidebar-mode', 'expanded');
        if(widget.id === 'widget-music') widget.classList.remove('sidebar-mode');
    };

    widgets.forEach(w => {
        w.addEventListener('dragstart', (e) => {
            e.dataTransfer.setData('text/plain', w.id);
            e.dataTransfer.effectAllowed = 'move';
            w.classList.add('dragging');
            document.body.classList.add('is-dragging');
        });
        w.addEventListener('dragend', () => {
             w.classList.remove('dragging');
             document.body.classList.remove('is-dragging');
             document.querySelectorAll('.widget').forEach(el => el.classList.remove('dragging'));
        });
    });

    const checkGridLimit = () => {
        const count = Array.from(gridContainer.children).filter(c => c.classList.contains('widget')).length;
        if (count >= 5) {
            alert('Main Grid is full (Max 5). Remove a widget first.');
            return false;
        }
        return true;
    };

    const handleDrop = (e, container) => {
        e.preventDefault();
        
        if (e.dataTransfer.getData('type') === 'sticker') {
            if (container !== document.body && container !== stickerLayer) return;
            const type = e.dataTransfer.getData('stickerType');
            const src = e.dataTransfer.getData('stickerSrc');
            const x = (e.clientX / window.innerWidth) * 100;
            const y = (e.clientY / window.innerHeight) * 100;
            
            config.stickers.push({
                id: 'st_' + Date.now(),
                type, src, x, y, rotation: 0
            });
            localStorage.setItem('et_stickers', JSON.stringify(config.stickers));
            renderStickers();
            return;
        }

        const id = e.dataTransfer.getData('text/plain');
        const draggable = document.getElementById(id);
        if (!draggable) return;

        cleanWidgetOnDrop(draggable);
        document.body.classList.remove('is-dragging');
        draggable.classList.remove('dragging');

        if (container === gridContainer) {
             if (draggable.parentElement !== gridContainer && !checkGridLimit()) return;
             const afterElement = getDragAfterElement(gridContainer, e.clientY);
             if (afterElement == null) gridContainer.appendChild(draggable);
             else gridContainer.insertBefore(draggable, afterElement);
        } else if (container === drawerContent) {
            drawerContent.appendChild(draggable);
        } else if (container.id === 'dropZone') {
            drawerContent.appendChild(draggable);
        }

        saveLayout();
    };

    [gridContainer, drawerContent, document.getElementById('dropZone')].forEach(c => {
        c.addEventListener('dragover', e => e.preventDefault());
        c.addEventListener('drop', e => handleDrop(e, c));
    });
    
    document.body.addEventListener('dragover', e => {
        if(e.dataTransfer.types.includes('type')) e.preventDefault();
    });
    document.body.addEventListener('drop', e => handleDrop(e, document.body));

    sidebarContainer.addEventListener('dragover', e => e.preventDefault());
    sidebarContainer.addEventListener('drop', e => {
        e.preventDefault();
        const id = e.dataTransfer.getData('text/plain');
        const draggable = document.getElementById(id);
        
        if (id !== 'widget-music') {
            alert('Only the Music Widget can be placed in the sidebar.');
            return;
        }
        
        cleanWidgetOnDrop(draggable);
        draggable.classList.remove('dragging');
        document.body.classList.remove('is-dragging');
        draggable.classList.add('sidebar-mode');
        sidebarContainer.insertBefore(draggable, sidebarPlaceholder);
        saveLayout();
    });
    
    sidebarPlaceholder.addEventListener('click', () => {
        const musicW = document.getElementById('widget-music');
        if (musicW) {
            cleanWidgetOnDrop(musicW);
            musicW.classList.add('sidebar-mode');
            sidebarContainer.insertBefore(musicW, sidebarPlaceholder);
            saveLayout();
        }
    });

    function getDragAfterElement(container, y) {
        const draggableElements = [...container.querySelectorAll('.widget:not(.dragging)')];
        return draggableElements.reduce((closest, child) => {
            const box = child.getBoundingClientRect();
            const offset = y - box.top - box.height / 2;
            if (offset < 0 && offset > closest.offset) return { offset: offset, element: child }; else return closest;
        }, { offset: Number.NEGATIVE_INFINITY }).element;
    }

    // --- Edit Mode ---
    const toggleEditMode = () => {
        isEditMode = !isEditMode;
        document.body.classList.toggle('edit-mode', isEditMode);
        document.querySelectorAll('.widget').forEach(w => w.setAttribute('draggable', isEditMode));
        if (isEditMode) widgetDrawer.classList.add('open'); else widgetDrawer.classList.remove('open');
        renderStickers();
    };
    
    // Drawer Tab Switcher Logic
    const drawerTabs = document.querySelectorAll('.tab-btn');
    drawerTabs.forEach(btn => {
        btn.addEventListener('click', () => {
            drawerTabs.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            const target = btn.dataset.tab;
            if (target === 'widgets') {
                document.getElementById('drawerContent').classList.add('active');
                document.getElementById('stickerContent').classList.remove('active');
            } else {
                document.getElementById('drawerContent').classList.remove('active');
                document.getElementById('stickerContent').classList.add('active');
            }
        });
    });
    
    closeDrawerBtn.addEventListener('click', () => { playSound('click'); if (isEditMode) toggleEditMode(); else widgetDrawer.classList.remove('open'); });
    document.querySelectorAll('.remove-btn').forEach(btn => btn.addEventListener('click', (e) => { playSound('click'); e.stopPropagation(); drawerContent.appendChild(btn.closest('.widget')); saveLayout(); }));
    document.getElementById('editToggle').addEventListener('click', () => { playSound('click'); toggleEditMode(); });

    // --- Search Engine Logic ---
    const engines = [
        { name: 'Google', url: 'https://www.google.com/search?q=', svg: '<svg viewBox="0 0 24 24"><path d="M12.48 10.92v3.28h7.84c-.24 1.84-.853 3.187-1.787 4.133-1.147 1.147-2.933 2.4-6.053 2.4-4.827 0-8.6-3.893-8.6-8.72s3.773-8.72 8.6-8.72c2.6 0 4.507 1.027 5.907 2.347l2.307-2.307C18.747 1.44 16.133 0 12.48 0 5.867 0 .533 5.333.533 12S5.867 24 12.48 24c3.44 0 6.053-1.147 8.213-3.307C22.96 18.52 23.68 15.52 23.68 13.107c0-.507-.053-.987-.147-1.48h-11.053z"/></svg>' },
        { name: 'Gemini', url: 'https://gemini.google.com/app?q=', svg: '<svg viewBox="0 0 24 24"><path d="M11.96 4a7.9 7.9 0 0 0-2.3 5.7A7.9 7.9 0 0 0 4 12a7.9 7.9 0 0 0 5.66 2.3 7.9 7.9 0 0 0 2.3 5.7 7.9 7.9 0 0 0 2.34-5.7A7.9 7.9 0 0 0 20 12a7.9 7.9 0 0 0-5.7-2.3A7.9 7.9 0 0 0 11.96 4z"/></svg>' },
        { name: 'ChatGPT', url: 'https://chat.openai.com/?q=', svg: '<svg viewBox="0 0 24 24"><path fill="currentColor" d="M22.282 9.821a5.985 5.985 0 0 0-.516-4.91 6.046 6.046 0 0 0-6.51-2.9A6.065 6.065 0 0 0 4.98 4.18a5.985 5.985 0 0 0-3.96 3.83 6.046 6.046 0 0 0 .743 7.097 5.985 5.985 0 0 0 .515 4.91 6.046 6.046 0 0 0 6.51 2.9 6.065 6.065 0 0 0 10.276-2.17 5.985 5.985 0 0 0 3.96-3.83 6.046 6.046 0 0 0-.742-7.096zm-1.4 2.868l-3.376 1.95a.86.86 0 0 1-1.127-.272l-1.09-1.89-1.135 1.964a.86.86 0 0 1-1.139.276l-3.32-1.916a.86.86 0 0 1-.302-1.168l1.09-1.89-1.077-1.864a.86.86 0 0 1 .302-1.168l3.376-1.95a.86.86 0 0 1 1.127.272l1.09 1.89 1.135-1.964a.86.86 0 0 1 1.139-.276l3.32 1.916a.86.86 0 0 1 .302 1.168l-1.09 1.89 1.077 1.864a.86.86 0 0 1-.302 1.168zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>' },
        { name: 'YouTube', url: 'https://www.youtube.com/results?search_query=', svg: '<svg viewBox="0 0 24 24"><path fill="currentColor" d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>' },
        { name: 'Spotify', url: 'https://open.spotify.com/search/', svg: '<svg viewBox="0 0 24 24"><path fill="currentColor" d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S16.6 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.837-.118-.958-.537-.12-.418.12-.837.54-.958 4.618-1.077 8.52-.66 11.76 1.32.36.18.479.659.24 1.078zm1.441-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141 4.2-1.32 9.6-0.66 13.261 1.621.419.24.6.839.48 1.2zm.119-3.3c-3.839-2.28-10.139-2.46-13.739-1.38-.541.18-1.141-.12-1.321-.66-.18-.54.12-1.14.66-1.32 4.2-1.2 11.1-0.96 15.419 1.68.48.24.66.84.421 1.32-.24.48-.84.6-1.44.36z"/></svg>' }
    ];

    let currentEngine = localStorage.getItem('et_engine') || 'Google';
    
    const renderSearchOptions = () => {
        const list = document.getElementById('engineOptions');
        const currentIcon = document.getElementById('currentEngineIconContainer');
        if(!list || !currentIcon) return;
        
        list.innerHTML = '';
        const active = engines.find(e => e.name === currentEngine) || engines[0];
        currentIcon.innerHTML = active.svg;
        
        engines.forEach(eng => {
            const div = document.createElement('div');
            div.className = 'option-item';
            div.innerHTML = `${eng.svg} <span>${eng.name}</span>`;
            div.onclick = (e) => {
                e.stopPropagation();
                currentEngine = eng.name;
                localStorage.setItem('et_engine', eng.name);
                renderSearchOptions();
                document.getElementById('searchSelect').classList.remove('active');
            };
            list.appendChild(div);
        });
    };
    
    renderSearchOptions();
    
    document.getElementById('searchSelect').addEventListener('click', (e) => {
        e.stopPropagation();
        document.getElementById('searchSelect').classList.toggle('active');
    });
    
    document.addEventListener('click', () => {
        document.getElementById('searchSelect').classList.remove('active');
    });
    
    const handleSearch = () => {
        const val = document.getElementById('searchInput').value.trim();
        if(val) {
            const eng = engines.find(e => e.name === currentEngine) || engines[0];
            window.location.href = eng.url + encodeURIComponent(val);
        }
    };
    
    document.getElementById('searchSubmit').addEventListener('click', handleSearch);
    document.getElementById('searchInput').addEventListener('keypress', (e) => {
        if(e.key === 'Enter') handleSearch();
    });

    const suggestionInput = document.getElementById('searchInput');
    const suggestionsList = document.getElementById('searchSuggestions');
    
    let debounceTimer;
    suggestionInput.addEventListener('input', (e) => {
        clearTimeout(debounceTimer);
        const query = e.target.value.trim();
        if(query.length < 1) {
            suggestionsList.style.display = 'none';
            return;
        }
        
        debounceTimer = setTimeout(async () => {
            try {
                // Using a proxy or direct if permissions allow
                const res = await fetch('https://suggestqueries.google.com/complete/search?client=firefox&q=' + encodeURIComponent(query));
                const data = await res.json();
                const suggestions = data[1];
                
                if(suggestions && suggestions.length > 0) {
                    suggestionsList.innerHTML = '';
                    suggestions.slice(0, 5).forEach(s => {
                        const div = document.createElement('div');
                        div.className = 'suggestion-item';
                        div.innerText = s;
                        div.onclick = () => {
                            suggestionInput.value = s;
                            suggestionsList.style.display = 'none';
                            handleSearch();
                        };
                        suggestionsList.appendChild(div);
                    });
                    suggestionsList.style.display = 'flex';
                } else {
                    suggestionsList.style.display = 'none';
                }
            } catch(e) { }
        }, 200);
    });
    
    document.addEventListener('click', (e) => {
        if(!suggestionInput.contains(e.target) && !suggestionsList.contains(e.target)) {
            suggestionsList.style.display = 'none';
        }
    });

    // --- Search Resize ---
    const searchResize = document.getElementById('searchResizeHandle');
    if (searchResize) {
        searchResize.addEventListener('click', (e) => {
            playSound('click');
            e.stopPropagation();
            const w = document.getElementById('widget-search');
            w.classList.toggle('half-width');
            localStorage.setItem('et_search_half', w.classList.contains('half-width'));
        });
    }

    // --- Context Menu ---
    const ctxMenu = document.getElementById('contextMenu');
    document.addEventListener('contextmenu', (e) => {
        if (e.target.closest('.widget') || e.target.closest('.dock-item')) return;
        e.preventDefault();
        ctxMenu.style.top = e.clientY + 'px';
        ctxMenu.style.left = e.clientX + 'px';
        ctxMenu.classList.add('active');
        
        ctxMenu.innerHTML = '';
        const addItem = (label, action) => {
            const div = document.createElement('div'); div.className = 'ctx-item';
            div.textContent = label; div.onclick = () => { action(); ctxMenu.classList.remove('active'); };
            ctxMenu.appendChild(div);
        };
        
        addItem('Edit Layout', toggleEditMode);
        addItem('Change Wallpaper', () => { document.getElementById('settingsModal').classList.add('open'); document.querySelector('[data-target="tab-appearance"]').click(); });
        addItem('Toggle Dock', () => {
            config.showDock = !config.showDock;
            localStorage.setItem('et_dock', config.showDock);
            document.getElementById('dockToggle').checked = config.showDock;
            // renderDock is no longer called here to prevent dependency issues, 
            // the setting in panel will handle it or reload is required if closed
            // OR we rely on the main settings panel update.
            // For now, simple reload of page or just trigger via setting panel is safer.
            // But to keep context menu functional, we can trigger the toggle in settings.
            const dt = document.getElementById('dockToggle');
            if(dt) { dt.checked = config.showDock; dt.dispatchEvent(new Event('change')); }
        });
        if (config.experimental) {
            addItem('Confetti!', startConfetti);
        }
    });
    
    document.addEventListener('click', () => ctxMenu.classList.remove('active'));

    const startConfetti = () => {
        const canvas = document.getElementById('matrixCanvas');
        const ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        canvas.classList.add('active');
        
        const particles = [];
        const colors = ['#d71921', '#ffffff', '#ff0000', '#222222', '#888888'];
        
        for(let i=0; i<400; i++) {
            particles.push({
                x: canvas.width / 2,
                y: canvas.height / 2,
                vx: (Math.random() - 0.5) * 25,
                vy: (Math.random() - 0.5) * 25,
                size: Math.random() * 6 + 2,
                color: colors[Math.floor(Math.random() * colors.length)],
                life: 150,
                decay: Math.random() * 0.5 + 0.5
            });
        }
        
        const draw = () => {
            if(!canvas.classList.contains('active')) return;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            let active = false;
            particles.forEach(p => {
                if(p.life > 0) {
                    active = true;
                    p.x += p.vx;
                    p.y += p.vy;
                    p.vy += 0.4;
                    p.vx *= 0.95;
                    p.vy *= 0.95;
                    p.life -= p.decay;
                    
                    ctx.fillStyle = p.color;
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.size, 0, Math.PI*2);
                    ctx.fill();
                }
            });
            if(active) requestAnimationFrame(draw);
            else {
                canvas.classList.remove('active');
                ctx.clearRect(0, 0, canvas.width, canvas.height);
            }
        };
        draw();
    };

    // --- Branding Easter Egg ---
    const brandLogo = document.getElementById('brandLogo');
    let clickCount = 0;
    let clickTimer;
    
    if (brandLogo) {
        brandLogo.addEventListener('click', () => {
            clickCount++;
            clearTimeout(clickTimer);
            clickTimer = setTimeout(() => { clickCount = 0; }, 2000);
            
            if (clickCount === 5) {
                document.body.classList.toggle('retro-mode');
                playSound('click');
                clickCount = 0;
            }
        });
    }

    // --- Modals ---
    const aboutModal = document.getElementById('aboutModal');
    const changelogModal = document.getElementById('changelogModal');
    
    document.getElementById('openAboutBtn').onclick = () => aboutModal.classList.add('open');
    document.getElementById('closeAbout').onclick = () => aboutModal.classList.remove('open');
    
    document.getElementById('openChangelogBtn').onclick = () => {
        const content = document.getElementById('changelogContent');
        content.innerHTML = '<div class="timeline">' + changelogs.map(log => `
            <div class="timeline-item">
                <div class="timeline-ver">v${log.version}</div>
                <div class="timeline-changes">${log.changes.map(c => '• ' + c).join('<br>')}</div>
            </div>
        `).join('') + '</div>';
        changelogModal.classList.add('open');
    };
    document.getElementById('closeChangelog').onclick = () => changelogModal.classList.remove('open');

    
    // --- Brief Settings ---
    const briefAuto = document.getElementById('briefAutoShow');
    if(briefAuto) {
        briefAuto.checked = config.briefAutoShow;
        briefAuto.addEventListener('change', (e) => {
            config.briefAutoShow = e.target.checked;
            localStorage.setItem('et_brief_auto', config.briefAutoShow);
        });
    }
    
    const briefTopic = document.getElementById('briefNewsTopic');
    if(briefTopic) {
        briefTopic.value = config.briefNewsTopic;
        briefTopic.addEventListener('change', (e) => {
            config.briefNewsTopic = e.target.value;
            localStorage.setItem('et_brief_topic', config.briefNewsTopic);
        });
    }

    const renderBriefSettings = () => {
        const list = document.getElementById('briefOrderList');
        if(!list) return;
        list.innerHTML = '';
        config.briefOrder.forEach((item, idx) => {
            const div = document.createElement('div'); div.className = 'dock-setting-item';
            div.innerHTML = `<div class="dock-setting-info"><span>${item.toUpperCase()}</span></div>
            <div class="dock-setting-controls">
                <div class="dock-ctrl-btn up" title="Move Up">↑</div>
                <div class="dock-ctrl-btn down" title="Move Down">↓</div>
            </div>`;
            
            div.querySelector('.up').onclick = () => {
                if(idx > 0) {
                    playSound('click');
                    [config.briefOrder[idx], config.briefOrder[idx-1]] = [config.briefOrder[idx-1], config.briefOrder[idx]];
                    localStorage.setItem('et_brief_order', JSON.stringify(config.briefOrder));
                    renderBriefSettings();
                }
            };
            div.querySelector('.down').onclick = () => {
                if(idx < config.briefOrder.length - 1) {
                    playSound('click');
                    [config.briefOrder[idx], config.briefOrder[idx+1]] = [config.briefOrder[idx+1], config.briefOrder[idx]];
                    localStorage.setItem('et_brief_order', JSON.stringify(config.briefOrder));
                    renderBriefSettings();
                }
            };
            list.appendChild(div);
        });
    };
    renderBriefSettings();

    // --- Tabs Logic ---
    const tabs = document.querySelectorAll('.settings-tab');
    const panes = document.querySelectorAll('.settings-pane');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            playSound('click');
            tabs.forEach(t => t.classList.remove('active'));
            panes.forEach(p => p.classList.remove('active'));
            tab.classList.add('active');
            const target = document.getElementById(tab.dataset.target);
            if(target) target.classList.add('active');
            // Clear search on tab switch
            const searchEl = document.getElementById('settingsSearch');
            if(searchEl) searchEl.value = '';
            document.querySelectorAll('.setting-row, .setting-section').forEach(el => el.classList.remove('hidden'));
        });
    });

    // --- Wallpaper Playground Tabs ---
    const wpTabs = document.querySelectorAll('.wp-tab');
    const wpViews = document.querySelectorAll('.wp-view');
    wpTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            playSound('click');
            wpTabs.forEach(t => t.classList.remove('active'));
            wpViews.forEach(v => v.classList.remove('active'));
            
            tab.classList.add('active');
            const target = document.getElementById(tab.dataset.target);
            if(target) target.classList.add('active');
        });
    });

    // --- Settings Search ---
    const searchInput = document.getElementById('settingsSearch');
    if(searchInput) {
        searchInput.addEventListener('input', (e) => {
            const term = e.target.value.toLowerCase();
            const activePane = document.querySelector('.settings-pane.active');
            if(!activePane) return;
            
            const rows = activePane.querySelectorAll('.setting-row');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                if(text.includes(term)) {
                    row.classList.remove('hidden');
                } else {
                    row.classList.add('hidden');
                }
            });
        });
    }

    // --- Modal Draggable ---
    let isDraggingModal = false;
    let dragStartX = 0, dragStartY = 0;
    const dragHandle = document.querySelector('.settings-drag-handle');
    
    if (dragHandle && settingsModal) {
        dragHandle.addEventListener('mousedown', (e) => {
            isDraggingModal = true;
            const rect = settingsModal.getBoundingClientRect();
            dragStartX = e.clientX - rect.left;
            dragStartY = e.clientY - rect.top;
            
            settingsModal.style.transform = 'none';
            settingsModal.style.left = rect.left + 'px';
            settingsModal.style.top = rect.top + 'px';
        });

        document.addEventListener('mousemove', (e) => {
            if (isDraggingModal) {
                e.preventDefault();
                const x = e.clientX - dragStartX;
                const y = e.clientY - dragStartY;
                settingsModal.style.left = x + 'px';
                settingsModal.style.top = y + 'px';
            }
        });

        document.addEventListener('mouseup', () => {
            isDraggingModal = false;
        });
    }

    // --- Theme & Layout ---
    const applyTheme = () => document.documentElement.setAttribute('data-theme', config.theme);
    
    const applyLayoutClasses = () => {
        document.body.classList.remove('align-left', 'align-right', 'align-center');
        document.body.classList.add('align-' + config.gridAlign);
        
        if (config.gridAlign !== 'center') {
            sidebarContainer.classList.remove('hidden');
        } else {
            sidebarContainer.classList.add('hidden');
             // If centered, move sidebar widget back to drawer if exists
             if (config.sidebarWidget) {
                 const w = document.getElementById(config.sidebarWidget);
                 if (w) { drawerContent.appendChild(w); w.classList.remove('sidebar-mode'); }
                 config.sidebarWidget = null;
                 localStorage.removeItem('et_sidebar_widget');
                 saveLayout(); // Global from interactionGrid.ts
             }
        }
    };

    // --- Wallpaper System ---
    const loadWallpaper = (src) => {
        const largePreview = document.getElementById('wpLargePreview');
        const overlay = document.getElementById('overlay');
        const bgVideo = document.getElementById('bgVideo');
        
        if (!src) {
            largePreview.innerHTML = '<span style="color:#666; font-size:10px; font-weight:bold;">NO WALLPAPER</span>';
            overlay.style.backgroundImage = '';
            overlay.classList.remove('active');
            bgVideo.src = '';
            bgVideo.classList.remove('active');
            config.bgImage = null;
            localStorage.removeItem('et_bg');
            return;
        }
        
        config.bgImage = src;
        localStorage.setItem('et_bg', src);
        
        largePreview.innerHTML = `<div class="wp-current-label">CURRENT</div>`;

        if (src.startsWith('data:video') || src.endsWith('.mp4')) {
            bgVideo.src = src;
            bgVideo.classList.add('active');
            overlay.classList.remove('active');
            overlay.classList.add('video-mode');
            bgVideo.play();
            
            const v = document.createElement('video');
            v.src = src; v.autoplay = true; v.loop = true; v.muted = true;
            v.style.width = '100%'; v.style.height = '100%'; v.style.objectFit = 'cover';
            largePreview.appendChild(v);
        } else {
            overlay.style.backgroundImage = 'url(' + src + ')';
            overlay.classList.add('active');
            overlay.classList.remove('video-mode');
            bgVideo.classList.remove('active');
            bgVideo.pause();
            
            largePreview.style.backgroundImage = 'url(' + src + ')';
        }
    };
    
    const renderWallpaperList = () => {
        const list = document.getElementById('wallpaperList');
        if(!list) return;
        list.innerHTML = '';
        
        const resetBtn = document.createElement('button');
        resetBtn.className = 'wp-preset reset-wp';
        resetBtn.title = 'Remove Wallpaper';
        resetBtn.innerHTML = '<svg viewBox="0 0 24 24" width="24" height="24" stroke="#d71921" stroke-width="2" fill="none"><path d="M18 6L6 18M6 6l12 12"/></svg>';
        resetBtn.onclick = () => { playSound('click'); loadWallpaper(null); };
        list.appendChild(resetBtn);
        
        const PRESET_WALLPAPERS = [
            "https://images.unsplash.com/photo-1604871000636-074fa5117945?q=80&w=3800&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=3800&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1531297461136-82lw8e415306?q=80&w=3800&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1614850523459-c2f4c699c52e?q=80&w=3800&auto=format&fit=crop"
        ];

        PRESET_WALLPAPERS.forEach(url => {
            const btn = document.createElement('button');
            btn.className = 'wp-preset';
            btn.style.backgroundImage = `url(${url})`;
            btn.onclick = () => { playSound('click'); loadWallpaper(url); };
            list.appendChild(btn);
        });
        
        config.userWallpapers.forEach((url, idx) => {
            const wrapper = document.createElement('div');
            wrapper.className = 'wp-user-wrapper';
            
            const btn = document.createElement('button');
            btn.className = 'wp-preset';
            if (url.startsWith('data:video')) {
                 btn.style.backgroundColor = '#222';
                 btn.innerHTML = '<span style="font-size:8px; color:white;">VIDEO</span>';
            } else {
                 btn.style.backgroundImage = `url(${url})`;
            }
            btn.onclick = () => { playSound('click'); loadWallpaper(url); };
            
            const delBtn = document.createElement('button');
            delBtn.className = 'wp-user-delete';
            delBtn.innerHTML = '×';
            delBtn.onclick = (e) => {
                e.stopPropagation();
                playSound('delete');
                if(confirm('Delete this wallpaper?')) {
                    config.userWallpapers.splice(idx, 1);
                    localStorage.setItem('et_user_wallpapers', JSON.stringify(config.userWallpapers));
                    if (config.bgImage === url) loadWallpaper(null);
                    renderWallpaperList();
                }
            };

            wrapper.appendChild(btn);
            wrapper.appendChild(delBtn);
            list.appendChild(wrapper);
        });
        
        const upBtn = document.createElement('button');
        upBtn.className = 'wp-preset add-wp';
        upBtn.innerHTML = '+';
        upBtn.onclick = () => { playSound('click'); document.getElementById('bgUpload').click(); };
        list.appendChild(upBtn);
    };

    const bgUpload = document.getElementById('bgUpload');
    if(bgUpload) {
        bgUpload.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (!file) return;
            if (file.size > 5 * 1024 * 1024) { alert('File too large (Max 5MB)'); return; }
            const reader = new FileReader();
            reader.onload = (evt) => {
                const res = evt.target.result;
                config.userWallpapers.push(res);
                localStorage.setItem('et_user_wallpapers', JSON.stringify(config.userWallpapers));
                loadWallpaper(res);
                renderWallpaperList();
            };
            reader.readAsDataURL(file);
        });
    }

    // --- Emoji Generator ---
    const emojiBtn = document.getElementById('emojiGenerateBtn');
    if(emojiBtn) {
        emojiBtn.addEventListener('click', () => {
            const str = document.getElementById('emojiInput').value || '⚡️';
            const bg = document.getElementById('emojiBgInput').value;
            const layout = document.getElementById('emojiLayoutSelect').value;
            
            const canvas = document.createElement('canvas');
            canvas.width = 1920;
            canvas.height = 1080;
            const ctx = canvas.getContext('2d');
            
            ctx.fillStyle = bg;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            let emojis = [];
            try {
                // @ts-ignore
                const segmenter = new Intl.Segmenter('en', { granularity: 'grapheme' });
                // @ts-ignore
                emojis = Array.from(segmenter.segment(str)).map(s => s.segment);
            } catch (e) {
                emojis = str.split('');
            }
            
            if(!emojis.length) return;
            
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            
            if (layout.startsWith('grid')) {
                let size = 80, gap = 120;
                if (layout === 'grid-small') { size = 50; gap = 80; }
                if (layout === 'grid-large') { size = 150; gap = 240; }
                
                ctx.font = size + 'px sans-serif';
                for (let y = 0; y < canvas.height + gap; y += gap) {
                    const rowIndex = Math.floor(y/gap);
                    const offset = (rowIndex % 2) * (gap/2);
                    for (let x = -gap; x < canvas.width + gap; x += gap) {
                         const eIndex = (Math.floor(x/gap) + rowIndex) % emojis.length;
                         const safeIndex = (eIndex % emojis.length + emojis.length) % emojis.length;
                         ctx.fillText(emojis[safeIndex], x + offset, y);
                    }
                }
            } else if (layout === 'radial') {
                 ctx.font = '80px sans-serif';
                 const cx = canvas.width/2, cy = canvas.height/2;
                 let r = 0, idx = 0;
                 while(r < 1200) {
                     const circum = 2 * Math.PI * r;
                     const count = r === 0 ? 1 : Math.floor(circum / 120);
                     for(let i=0; i<count; i++) {
                         const ang = (i/count) * Math.PI * 2;
                         ctx.save();
                         ctx.translate(cx + Math.cos(ang)*r, cy + Math.sin(ang)*r);
                         ctx.rotate(ang + Math.PI/2);
                         ctx.fillText(emojis[idx % emojis.length], 0, 0);
                         ctx.restore();
                         idx++;
                     }
                     r += 120;
                 }
            }
            
            const url = canvas.toDataURL('image/png');
            config.userWallpapers.push(url);
            localStorage.setItem('et_user_wallpapers', JSON.stringify(config.userWallpapers));
            loadWallpaper(url);
            renderWallpaperList();
            playSound('click');
        });
    }

    // --- Init Settings Values ---
    const initSettingsUI = () => {
        applyTheme();
        // Font
        document.documentElement.style.setProperty('--font-custom', config.font);
        
        // Initial Layout
        applyLayoutClasses();

        // Values
        document.documentElement.style.setProperty('--dock-scale', config.dockScale);
        document.documentElement.style.setProperty('--blur-strength', config.blur + 'px');
        document.documentElement.style.setProperty('--radius', config.borderRadius + 'px');
        
        const cdLabel = document.getElementById('countdownLabelInput');
        if(cdLabel) cdLabel.value = config.countdownLabel;
        const cdDate = document.getElementById('countdownDateInput');
        if(cdDate) cdDate.value = config.countdownDate;

        // Experimental
        const expToggle = document.getElementById('experimentalToggle');
        const coverSizeRow = document.getElementById('coverSizeRow');
        const coverSizeRange = document.getElementById('coverSizeRange');
        const codeRow = document.getElementById('experimentalCodeRow');
        const fontRow = document.getElementById('fontRow');
        
        const ensureElement = (id, html) => {
             if(!document.getElementById(id)) {
                 const div = document.createElement('div'); div.id = id; div.className = 'setting-row hidden';
                 div.innerHTML = html;
                 if(expToggle) expToggle.closest('.setting-row').parentNode.insertBefore(div, expToggle.closest('.setting-row').nextSibling);
             }
             return document.getElementById(id);
        }

        const ambRow = document.getElementById('ambientRow') || ensureElement('ambientRow', '<span>AMBIENT LIGHTING</span><label class="switch"><input type="checkbox" id="ambientToggle"><span class="slider round"></span></label>');
        const glowRow = document.getElementById('albumGlowRow') || ensureElement('albumGlowRow', '<span>DYNAMIC ALBUM GLOW</span><label class="switch"><input type="checkbox" id="albumGlowToggle"><span class="slider round"></span></label>');
        const emojiRow = document.getElementById('emojiIconsRow');

        if(expToggle) expToggle.checked = config.experimental;
        
        const toggleExpUI = () => {
            if(config.experimental) {
                if(coverSizeRow) coverSizeRow.classList.remove('hidden');
                if(codeRow) codeRow.classList.remove('hidden');
                if(ambRow) ambRow.classList.remove('hidden');
                if(glowRow) glowRow.classList.remove('hidden');
                if(emojiRow) emojiRow.classList.remove('hidden');
            } else {
                if(coverSizeRow) coverSizeRow.classList.add('hidden');
                if(codeRow) codeRow.classList.add('hidden');
                if(ambRow) ambRow.classList.add('hidden');
                if(glowRow) glowRow.classList.add('hidden');
                if(emojiRow) emojiRow.classList.add('hidden');
            }
        };
        toggleExpUI();
        
        if(coverSizeRange) {
            coverSizeRange.value = config.coverSize;
            coverSizeRange.addEventListener('input', (e) => {
                config.coverSize = e.target.value;
                localStorage.setItem('et_cover_size', config.coverSize);
                document.documentElement.style.setProperty('--cover-size', config.coverSize + 'px');
            });
        }
        
        if (config.experimental) document.documentElement.style.setProperty('--cover-size', config.coverSize + 'px');
        else document.documentElement.style.setProperty('--cover-size', '110px');

        if(expToggle) {
            expToggle.addEventListener('change', (e) => {
                playSound('click');
                config.experimental = e.target.checked;
                localStorage.setItem('et_experimental', config.experimental);
                toggleExpUI();
                if(config.experimental) document.documentElement.style.setProperty('--cover-size', config.coverSize + 'px');
                else document.documentElement.style.setProperty('--cover-size', '110px');
            });
        }

        const ambToggle = document.getElementById('ambientToggle');
        if (ambToggle) {
            ambToggle.checked = config.ambientMode;
            const applyAmbient = () => {
                if (config.ambientMode) document.body.classList.add('ambient-mode');
                else document.body.classList.remove('ambient-mode');
            };
            applyAmbient();
            ambToggle.addEventListener('change', (e) => {
                playSound('click');
                config.ambientMode = e.target.checked;
                localStorage.setItem('et_ambient', config.ambientMode);
                applyAmbient();
            });
        }

        const glowToggle = document.getElementById('albumGlowToggle');
        if (glowToggle) {
            glowToggle.checked = config.albumGlow;
            glowToggle.addEventListener('change', (e) => {
                playSound('click');
                config.albumGlow = e.target.checked;
                localStorage.setItem('et_album_glow', config.albumGlow);
                const artContainer = document.querySelector('.album-art-container');
                if (artContainer) {
                    if (config.albumGlow) artContainer.classList.add('active-glow');
                    else artContainer.classList.remove('active-glow');
                }
            });
        }
        
        const emojiToggle = document.getElementById('emojiIconsToggle');
        if(emojiToggle) {
            emojiToggle.checked = config.emojiIcons;
            emojiToggle.addEventListener('change', (e) => {
                playSound('click');
                config.emojiIcons = e.target.checked;
                localStorage.setItem('et_emoji_icons', config.emojiIcons);
                updateHeaderIcons(); // Global from interactionGrid.ts
                renderDock();
            });
        }

        const codeInput = document.getElementById('experimentalCodeInput');
        const radiusRow = document.getElementById('borderRadiusRow');
        const radiusRange = document.getElementById('borderRadiusRange');
        const radiusVal = document.getElementById('borderRadiusVal');

        if(codeInput) {
            codeInput.addEventListener('input', (e) => {
                const val = e.target.value.toLowerCase();
                if (val === 'font' && fontRow) fontRow.classList.remove('hidden');
                
                // Easter Eggs
                if (val === 'zen') document.body.classList.toggle('minimal-mode');
                if (val === 'retro') document.body.classList.toggle('retro-mode');
                if (val === 'party') { if(typeof startConfetti === 'function') startConfetti(); }
                if (val === 'do a barrel roll') {
                    document.body.style.transition = 'transform 1s ease';
                    document.body.style.transform = 'rotate(360deg)';
                    setTimeout(() => { document.body.style.transform = ''; }, 1000);
                }
            });
        }

        if(radiusRange) {
            radiusRange.value = config.borderRadius;
            radiusVal.textContent = config.borderRadius;
            radiusRange.addEventListener('input', (e) => {
                config.borderRadius = e.target.value;
                localStorage.setItem('et_radius', config.borderRadius);
                document.documentElement.style.setProperty('--radius', config.borderRadius + 'px');
                radiusVal.textContent = config.borderRadius;
            });
        }

        // Init Wallpaper
        if (config.bgImage) loadWallpaper(config.bgImage);
        else document.getElementById('wpLargePreview').innerHTML = '<span style="color:#666; font-size:10px; font-weight:bold;">NO WALLPAPER ACTIVE</span>';
        renderWallpaperList();
        
        // Init Dock Mag Strength
        const dockMagRange = document.getElementById('dockMagRange');
        if(dockMagRange) {
            dockMagRange.value = config.dockMagStrength;
            dockMagRange.addEventListener('input', (e) => {
                config.dockMagStrength = parseFloat(e.target.value);
                localStorage.setItem('et_dock_mag_str', config.dockMagStrength);
            });
        }
    };
    initSettingsUI();

    document.getElementById('resetAllBtn').addEventListener('click', () => {
        if(confirm('Are you sure you want to reset all settings to default? This cannot be undone.')) {
            localStorage.clear();
            window.location.reload();
        }
    });
    
    document.getElementById('removeAllStickersBtn').addEventListener('click', () => {
        if(confirm('Remove ALL stickers from the home screen?')) {
            config.stickers = [];
            localStorage.setItem('et_stickers', JSON.stringify(config.stickers));
            renderStickers();
        }
    });

    document.getElementById('closeSettings').addEventListener('click', () => {
        playSound('click');
        settingsModal.classList.remove('open');
        setTimeout(() => {
            settingsModal.style.transform = 'translate(-50%, -50%) scale(0.9)';
            settingsModal.style.top = '50%';
            settingsModal.style.left = '50%';
        }, 300);
    });

    const closeSticky = document.getElementById('closeSticky');
    if(closeSticky) closeSticky.addEventListener('click', () => document.getElementById('stickyNoteModal').classList.remove('open'));
    
    const closeLibrary = document.getElementById('closeLibrary');
    if(closeLibrary) closeLibrary.addEventListener('click', () => document.getElementById('libraryModal').classList.remove('open'));
    
    // --- User ID Card Logic ---
    const card = document.getElementById('userIdCard');
    const cardWrapper = document.querySelector('.user-id-card-wrapper');
    const cardName = document.getElementById('cardNameDisplay');
    const cardId = document.getElementById('cardIdDisplay');
    const cardAvatar = document.getElementById('cardAvatar');

    // Init Values
    if (card) {
        // Fix for name saving
        if(config.userCard && config.userCard.name) {
             cardName.textContent = config.userCard.name;
        }
        
        cardId.innerText = config.userCard.id;
        card.style.setProperty('--card-color', config.userCard.color);
        card.style.setProperty('--card-font', config.userCard.font);

        if (config.userCard.image) {
            cardAvatar.innerHTML = `<img src="${config.userCard.image}">`;
        } else {
            // Ensure default stick man is present if no image
            if (!cardAvatar.querySelector('.default-avatar-icon')) {
                cardAvatar.innerHTML = `
                <div class="default-avatar-icon">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                    </svg>
                </div>`;
            }
        }

        // Tilt Effect
        cardWrapper.addEventListener('mousemove', (e) => {
            const rect = cardWrapper.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const rotateX = (centerY - y) / 10; // Max rotation deg
            const rotateY = (x - centerX) / 10;
            
            card.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
        });
        
        cardWrapper.addEventListener('mouseleave', () => {
            card.style.transform = 'rotateX(0) rotateY(0)';
        });

        cardName.addEventListener('input', (e) => {
            if(!config.userCard) config.userCard = {};
            config.userCard.name = (e.target).textContent;
            localStorage.setItem('et_user_card', JSON.stringify(config.userCard));
        });
    }

    // --- Dock Logic ---
    const dock = document.getElementById('dock');
    const dockContainer = document.getElementById('dockContainer');

    const renderDock = () => {
        dock.innerHTML = '';
        if (config.showDock) dockContainer.classList.remove('hidden'); else dockContainer.classList.add('hidden');
        if (config.dockMagnification) dockContainer.classList.add('dock-magnify-active'); else dockContainer.classList.remove('dock-magnify-active');
        
        const createTooltip = (text) => {
            if(!config.dockHoverName) return '';
            return `<div class="dock-tooltip">${text}</div>`;
        };
        
        const addBtn = (svg, emoji, text, onClick) => {
            const div = document.createElement('div'); div.className = 'dock-item';
            div.innerHTML = (config.emojiIcons ? '<span style="font-size:22px;">' + emoji + '</span>' : svg) + createTooltip(text); 
            div.onclick = onClick; dock.appendChild(div);
        };
        addBtn(
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><line x1="12" y1="18" x2="12" y2="12"/><line x1="9" y1="15" x2="15" y2="15"/><polyline points="14 2 14 8 20 8"/></svg>', 
            '🗒️', 'Notes',
            () => document.getElementById('stickyNoteModal').classList.add('open')
        );
        addBtn(
            '<svg viewBox="0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>',
            '🔖', 'Library',
            () => document.getElementById('libraryModal').classList.add('open')
        );

        pinnedItems.forEach((item, idx) => {
            const div = document.createElement('div'); div.className = 'dock-item';
            div.onclick = () => window.location.href = item.url;
            div.oncontextmenu = (e) => {
                e.preventDefault();
                if(confirm('Remove ' + item.title + ' from dock?')) {
                    pinnedItems.splice(idx, 1);
                    localStorage.setItem('et_pinned', JSON.stringify(pinnedItems));
                    renderDock();
                }
            };
            const img = document.createElement('img'); img.src = 'https://www.google.com/s2/favicons?sz=64&domain_url=' + item.url;
            div.appendChild(img); 
            if(config.dockHoverName) div.innerHTML += createTooltip(item.title);
            dock.appendChild(div);
        });

        const setBtn = document.createElement('div'); setBtn.className = 'dock-item';
        setBtn.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.488.488 0 0 0-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.484.484 0 0 0-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.58 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>' + createTooltip('Settings');
        setBtn.onclick = () => { playSound('click'); settingsModal.classList.add('open'); };
        dock.appendChild(setBtn);
        
        renderDockSettings();
    };
    
    // Wave Animation Logic
    const handleDockWave = (e) => {
        if(!config.dockMagnification) return;
        
        const items = dock.querySelectorAll('.dock-item');
        const mx = e.clientX;
        
        items.forEach(item => {
            const rect = item.getBoundingClientRect();
            const cx = rect.left + rect.width / 2;
            const dist = Math.abs(mx - cx);
            const range = 150; // Influence range in px
            
            if (dist < range) {
                // Cosine interpolation for smooth wave
                // dist 0 -> scale max. dist range -> scale 1
                const val = Math.cos((dist / range) * (Math.PI / 2)); 
                const scale = 1 + (config.dockMagStrength * Math.pow(val, 2)); // Dynamic strength
                
                item.style.transform = `scale(${scale}) translateY(${(scale - 1) * -15}px)`;
                // Push neighbors by increasing margins
                item.style.margin = `0 ${(scale - 1) * 10}px`;
            } else {
                item.style.transform = 'scale(1)';
                item.style.margin = '0';
            }
        });
    };
    
    const resetDockWave = () => {
        if(!config.dockMagnification) return;
        const items = dock.querySelectorAll('.dock-item');
        items.forEach(item => {
            item.style.transform = '';
            item.style.margin = '';
        });
    };
    
    // Attach Wave Listeners
    dock.addEventListener('mousemove', handleDockWave);
    dock.addEventListener('mouseleave', resetDockWave);

    const renderDockSettings = () => {
        const list = document.getElementById('dockSettingsList');
        if(!list) return;
        list.innerHTML = '';
        
        // Ensure Mag Slider Visibility
        const magRow = document.getElementById('dockMagRow');
        if(magRow) {
            if(config.dockMagnification) magRow.classList.remove('hidden');
            else magRow.classList.add('hidden');
        }

        const dockTab = document.getElementById('tab-dock');
        if(dockTab && !document.getElementById('dockMagToggle')) {
            const section = dockTab.querySelector('.setting-section');
            if(section) {
                const addToggle = (id, label, checked, cb) => {
                    const row = document.createElement('div');
                    row.className = 'setting-row';
                    row.innerHTML = `<span class="setting-label">${label}</span><label class="switch"><input type="checkbox" id="${id}"><span class="slider round"></span></label>`;
                    const ref = section.querySelector('.setting-row:nth-child(2)'); // Insert after 'Show Dock'
                    if(ref) section.insertBefore(row, ref.nextSibling);
                    else section.appendChild(row);
                    
                    const el = document.getElementById(id);
                    el.checked = checked;
                    el.addEventListener('change', cb);
                };
                
                addToggle('dockMagToggle', 'MAGNIFICATION EFFECT', config.dockMagnification, (e) => {
                     playSound('click');
                     config.dockMagnification = e.target.checked;
                     localStorage.setItem('et_dock_mag', config.dockMagnification);
                     renderDock();
                     const r = document.getElementById('dockMagRow');
                     if(r) { if(config.dockMagnification) r.classList.remove('hidden'); else r.classList.add('hidden'); }
                });
                
                addToggle('dockNamesToggle', 'HOVER NAMES', config.dockHoverName, (e) => {
                     playSound('click');
                     config.dockHoverName = e.target.checked;
                     localStorage.setItem('et_dock_names', config.dockHoverName);
                     renderDock();
                });
            }
        }

        pinnedItems.forEach((item, idx) => {
            const div = document.createElement('div'); div.className = 'dock-setting-item';
            div.innerHTML = `<div class="dock-setting-info"><img src="https://www.google.com/s2/favicons?sz=64&domain_url=${item.url}"><span>${item.title}</span></div>
            <div class="dock-setting-controls">
                <div class="dock-ctrl-btn up" title="Move Up">↑</div>
                <div class="dock-ctrl-btn down" title="Move Down">↓</div>
                <div class="dock-ctrl-btn delete" title="Delete">×</div>
            </div>`;
            
            const up = div.querySelector('.up');
            const down = div.querySelector('.down');
            const del = div.querySelector('.delete');
            
            up.onclick = () => {
                if(idx > 0) {
                    playSound('click');
                    [pinnedItems[idx], pinnedItems[idx-1]] = [pinnedItems[idx-1], pinnedItems[idx]];
                    localStorage.setItem('et_pinned', JSON.stringify(pinnedItems));
                    renderDock();
                }
            };
            down.onclick = () => {
                if(idx < pinnedItems.length - 1) {
                    playSound('click');
                    [pinnedItems[idx], pinnedItems[idx+1]] = [pinnedItems[idx+1], pinnedItems[idx]];
                    localStorage.setItem('et_pinned', JSON.stringify(pinnedItems));
                    renderDock();
                }
            };
            del.onclick = () => {
                if(confirm('Remove ' + item.title + '?')) {
                    playSound('delete');
                    pinnedItems.splice(idx, 1);
                    localStorage.setItem('et_pinned', JSON.stringify(pinnedItems));
                    renderDock();
                }
            };
            list.appendChild(div);
        });
    };

    renderDock();
    document.getElementById('addDockBtn').addEventListener('click', () => {
        playSound('click');
        const name = document.getElementById('dockTitleInput').value.trim();
        const url = document.getElementById('dockUrlInput').value.trim();
        if(name && url) {
            let validUrl = url.startsWith('http') ? url : 'https://' + url;
            pinnedItems.push({ title: name, url: validUrl });
            localStorage.setItem('et_pinned', JSON.stringify(pinnedItems));
            document.getElementById('dockTitleInput').value = '';
            document.getElementById('dockUrlInput').value = '';
            renderDock();
        }
    });

    // --- Pill Switches ---
    const setupPill = (id, count, callback) => {
        const container = document.getElementById(id);
        if(!container) return () => {};
        
        const slider = container.querySelector('.pill-slider');
        const btns = container.querySelectorAll('.pill-btn');
        slider.style.width = `calc((100% - 8px) / ${count})`;

        btns.forEach((btn, idx) => {
            btn.addEventListener('click', () => {
                playSound('click');
                btns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                slider.style.transform = `translateX(${idx * 100}%)`;
                callback(btn.dataset.value);
            });
        });

        return (val) => {
            let activeIdx = 0;
            btns.forEach((btn, idx) => {
                if(btn.dataset.value === val) {
                    btn.classList.add('active');
                    activeIdx = idx;
                } else btn.classList.remove('active');
            });
            slider.style.transform = `translateX(${activeIdx * 100}%)`;
        };
    };

    const updateThemePill = setupPill('themePill', 3, (val) => {
        config.theme = val;
        localStorage.setItem('et_theme', config.theme);
        applyTheme();
    });
    updateThemePill(config.theme);

    const updateFontPill = setupPill('fontPill', 4, (val) => {
        config.font = val;
        localStorage.setItem('et_font', config.font);
        document.documentElement.style.setProperty('--font-custom', config.font);
    });
    updateFontPill(config.font);

    const updateLayoutPill = setupPill('layoutPill', 3, (val) => {
        config.gridAlign = val;
        localStorage.setItem('et_grid_align', config.gridAlign);
        applyLayoutClasses();
    });
    updateLayoutPill(config.gridAlign);

    // --- Inputs Listeners ---
    document.getElementById('blurRange').value = config.blur;
    document.getElementById('blurRange').addEventListener('input', (e) => {
        const val = e.target.value; config.blur = val; localStorage.setItem('et_blur', val);
        document.documentElement.style.setProperty('--blur-strength', val + 'px');
    });
    
    document.getElementById('userNameInput').value = config.userName;
    document.getElementById('userNameInput').addEventListener('input', (e) => {
        config.userName = e.target.value; localStorage.setItem('et_name', e.target.value);
        document.getElementById('userNameDisplay').textContent = e.target.value || 'USER';
    });
    
    document.getElementById('format24h').checked = config.use24h;
    document.getElementById('format24h').addEventListener('change', (e) => { 
        playSound('click'); 
        config.use24h = e.target.checked; localStorage.setItem('et_24h', e.target.checked); updateTime(); 
    });
    
    document.getElementById('showSeconds').checked = config.showSeconds;
    document.getElementById('showSeconds').addEventListener('change', (e) => { 
        playSound('click');
        config.showSeconds = e.target.checked; localStorage.setItem('et_seconds', e.target.checked); updateTime(); 
    });
    
    const dockRange = document.getElementById('dockScaleRange');
    dockRange.value = config.dockScale;
    dockRange.addEventListener('input', (e) => {
        const val = e.target.value; config.dockScale = val; localStorage.setItem('et_dock_scale', val);
        document.documentElement.style.setProperty('--dock-scale', val);
    });
    
    document.getElementById('dockToggle').checked = config.showDock;
    document.getElementById('dockToggle').addEventListener('change', (e) => {
         playSound('click');
         config.showDock = e.target.checked; localStorage.setItem('et_dock', e.target.checked); renderDock();
    });
    
    document.getElementById('dockAutoHide').checked = config.dockAutoHide;
    document.getElementById('dockAutoHide').addEventListener('change', (e) => {
        playSound('click');
        config.dockAutoHide = e.target.checked;
        localStorage.setItem('et_dock_hide', e.target.checked);
        updateDockAutoHide();
    });
    
    const handleDockHover = (e) => {
        if(window.innerHeight - e.clientY < 100) dockContainer.style.opacity = '1';
        else dockContainer.style.opacity = '0';
    };
    
    const updateDockAutoHide = () => {
        if(config.dockAutoHide) {
            dockContainer.style.opacity = '0';
            dockContainer.style.transition = 'opacity 0.3s ease, transform 0.4s ease';
            document.addEventListener('mousemove', handleDockHover);
        } else {
            dockContainer.style.opacity = '1';
            document.removeEventListener('mousemove', handleDockHover);
        }
    };
    updateDockAutoHide();
    
    // --- Version Label ---
    document.getElementById('versionLabel').onclick = () => {
        if(config.experimental) startConfetti(); // Global from interactionGrid.ts
    };

});